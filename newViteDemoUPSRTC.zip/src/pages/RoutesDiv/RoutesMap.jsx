import React from 'react'

const RoutesMap = () => {
  return (

    <div className='w-100'>
    <img className='w-100' src='/assets/rouMap.svg' alt=''/>
    </div>
    
  )
}

export default RoutesMap