import React from 'react'

const DashBoard = () => {
  return (
    <div className='w-100' style={{paddingTop:"14px"}}>
    <img className='w-100' src='/assets/images/dashboard1.png' alt='Loading....'/>
    </div>
  )
}

export default DashBoard