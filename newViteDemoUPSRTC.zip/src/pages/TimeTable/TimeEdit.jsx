import React from 'react'

const TimeEdit = () => {
  return (
    <div className='w-100'>
    <img className='w-100' src='/assets/timetable973.svg' alt=''/>
    </div>
    
  )
}

export default TimeEdit