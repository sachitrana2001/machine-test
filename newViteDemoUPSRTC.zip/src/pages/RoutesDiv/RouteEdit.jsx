import React from 'react'

const RouteEdit = () => {
  return (
  
    <div className='w-100'>
    <img className='w-100' src='/assets/routedit.svg' alt=''/>
    </div>
  )
}

export default RouteEdit