export { default as DocumentUploader } from "./documentUploder";
export { default as ImageDetails } from "./imageDetails";
export { default as Sliders } from "./sliders";
export { default as TextDetails } from "./textDetails";
