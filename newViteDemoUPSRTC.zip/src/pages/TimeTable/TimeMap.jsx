import React from 'react'

const TimeMap = () => {
  return (
    <div className='w-100'>
    <img className='w-100' src='/assets/timetable972.svg' alt=''/>
    </div>
    
  )
}

export default TimeMap